const { prisma } = require('./generated/prisma-client')
const { GraphQLServer } = require('graphql-yoga')

const resolvers = {
  Query: {
    reorders(root, args, ctx){
      return ctx.prisma.productses({

      })
    },
    inventories(root, args, ctx){
      return ctx.prisma.inventories({

      })
    },
    orderlines(root, args, ctx){
      return ctx.prisma.orderlines({

      })
    },
    productses(root, args, ctx){
      return ctx.prisma.productses({  //This finds all products from the index.js 

      })
    },
    //Other methods like reorders() go here and inventory() to return info, if you want to POST info you need to use a mutation.
    // ... like before
    orderlineses(root, args, ctx){
      return ctx.prisma.orderlineses({

      })
    },
    categorieses(root, args, ctx){
      return ctx.prisma.categorieses({

      })
    },

  },
  Mutation: {
    createProducts(root, args, ctx){
      return ctx.prisma.createProducts({
        prod_id: args.prod_id,
        category: args.category,
        title: args.title,
        actor: args.actor,
        price: args.price,
        special: args.special,
        common_prod_id: args.common_prod_id
      })
    },
    createReorder(root, args, ctx){
      return ctx.prisma.createReorder({
        prod_id: args.prod_id,
        date_low: args.date_low,
        quan_low: args.quan_low,
        date_reordered: args.date_reordered,
        quan_reordered: args.quan_reordered,
        date_expected: args.date_expected
      })
    },
    createCategories(root, args, ctx){
      return ctx.prisma.createCategories({
        category: args.category,
        categoryname: args.categoryname
      })
    },
    createOrderlines(root, args, ctx){
      return ctx.prisma.createOrderlines({
        order_id: args.order_id,
        prod_id: args.prod_id,
        quantity: args.quantity,
        order_date: args.order_date
      })
    },
    createInventory(root, args, ctx){
      return ctx.prisma.createOrderLines({
        prod_id: args.prod_id,
        quan_in_stock: args.quan_in_stock,
        sales: args.sales
      })
    }
  },
  Products: {
    
  }
}
const server = new GraphQLServer({
    typeDefs: './schema.graphql',
    resolvers,
    context: {
      prisma
    },
  })
  server.start(() => console.log('Server is running on http://localhost:4000')) //Remember to be using localhost:4000 and not 4466