// Express for webserver
const express = require('express');
// sequelize for database
const Sequelize = require('sequelize');

const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({extended: true }));
app.use(bodyParser.json());
const port = 3000;

const sequelize = new Sequelize(`postgres://postgres@localhost:5432/pgguide`);
// Operators
const op = Sequelize.Op;

////////////////////////// USERS /////////////////////////////////////////////
const Users = sequelize.define('users', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id',
        primaryKey: true
    },
    email: { type: Sequelize.STRING, field: 'email' },
    password: { type: Sequelize.STRING, field: 'password' },
    details: { type: Sequelize.HSTORE, field: 'details' },
    created_at: { type: Sequelize.DATE },
    deleted_at: { type: Sequelize.DATE }
}, {
    timestamps: false
});

//// GET ALL USERS
app.get('/users', (req, res, next) => {

    Users.findAll({}, 
		{
			
        }).then(result => {
            res.json(result);
        });
});

/*//////////////////////// PURCHASES /////////////////////////////////////////////
const Purchases = sequelize.define('purchases', {
    price: { type: Sequelize.NUMERIC },
    quantity: { type: Sequelize.INTEGER },
    state: { type: Sequelize.STRING, field: 'state' },
    name: { type: Sequelize.STRING, field: 'name' },
    address: { type: Sequelize.STRING, field: 'address' },
    zipcode: { type: Sequelize.INTEGER },
    email: { type: Sequelize.STRING, field: 'email' },
    title: { type: Sequelize.STRING, field: 'title' },
}, {
    timestamps: false
});

//// GET ALL PURCHASES
app.get('/purchases', (req, res, next) => {

    Purchases.findAll({}, 
		{
			
        }).then(result => {
            res.json(result);
        });
});*/

//////////////////////////// PRODUCTS ////////////////////////////////////////
const Products = sequelize.define('products', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id',
        primaryKey: true
    },
    title: { type: Sequelize.STRING },
    price: { type: Sequelize.NUMERIC },
    tags: { type: Sequelize.ARRAY(Sequelize.STRING)},
    created_at: { type: Sequelize.DATE },
    deleted_at: { type: Sequelize.DATE }
}, {
    timestamps: false
});

//// APP GET ALL PRODUCTS 
//GET /products[?name=string]
//List all products

app.get('/products', (req, res, next) => {

    //Test to find all
    /*Products.findAll({}, 
		{
			
        }).then(result => {
            res.json(result);
        });*/

    // Now find with the specified product
    // If it matches return safequery name
    // If not just return all products
    const name = req.query.name; // ?name=

    if (name !== undefined) {
        Products.findAll({
            where: {
                title: {
                    [op.iLike]: `%${name}%`
                }
            },
        }).then((result) => {
            res.json(result);
            res.end();
        });
    } else {
        Products.findAll({
        }).then((result) => {
            res.json(result);
        });
    }
});

//APP GET PRODUCTS ID
//Passes in ID as a param if it finds a match
// it displays one other wise it has a 404 error
//GET /products/:id
//Show details of the specified products

app.get('/products/:id', (req, res, next) => {
    const id = req.params.id;

    if (id !== undefined && !isNaN(id)) {
        Products.findOne({
            where: {
                id: {
                    [op.eq]: id
                }
            }
        }).then((result) => {
            res.json(result);
            res.end();
        });
    } else {
        res.status(404);
        res.end();
    }
});


//POST /products
// Passes in the id to find the json object
// Then updates any values that were changed
//Create a new product instance
// APP POST PRODUCTS
app.post('/products/:id', (req, res, next) => {
    const id = req.params.id;
    const body = req.body;
    Products.update({
        title: body.title,
        price: body.price,
        tags: body.tags
    }, {
        where: {
            id: {
                [op.eq]: id
            }
        }
    }).then((result) => {
        res.json(result);
        res.end();
    });
});


// APP PUT PRODUCTS
// Creates a new body with what was entered
//PUT /products/:id
//Update an existing product
app.put('/products', (req, res, next) => {
    const body = req.body;
    Products.create({
        id: sequelize.literal('DEFAULT'),
        title: body.title,
        price: body.price,
        tags: body.tags,
        created_at: sequelize.literal('CURRENT_TIMESTAMP')
    }).then((result) => {
        res.json(result);
        res.end();
    });
});


// APP DELETE PRODUCTS
// Takes the entire ID of an object and then deletes it
//DELETE /products/:id
//Remove an existing product
app.delete('/products/:id', (req, res, next) => {
    const id = req.params.id;

    //Find the id that was specified and delete it
    Products.destroy({
        where: {
            id: {
                [op.eq]: id
            }
        }
    }).then((result) => {
        res.json(result);
        res.end();
    });
});

const server = app.listen(port, () => {
    console.log(`Listening on port ${port}!`)
});