const { prisma } = require('./generated/prisma-client')
const { GraphQLServer } = require('graphql-yoga')

const resolvers = {
  Query: {
    reorders(root, args, ctx){
      return ctx.prisma.productses({

      })
    },
    inventories(root, args, ctx){
      return ctx.prisma.inventories({

      })
    },
    orderlines(root, args, ctx){
      return ctx.prisma.orderlines({

      })
    },
    productses(root, args, ctx){
      return ctx.prisma.productses({  //This finds all products from the index.js 

      })
    },
    //Other methods like reorders() go here and inventory() to return info, if you want to POST info you need to use a mutation.
    // ... like before
    orderlineses(root, args, ctx){
      return ctx.prisma.orderlineses({

      })
    },
    categorieses(root, args, ctx){
      return ctx.prisma.categorieses({

      })
    },

  },
  Mutation: {
    createProducts(root, args, ctx){
      return ctx.prisma.createProducts({
        prod_id: args.prod_id,
        category: args.category,
        title: args.title,
        actor: args.actor,
        price: args.price,
        special: args.special,
        common_prod_id: args.common_prod_id
      })
    }
  },
  Products: {
    
  }
}
const server = new GraphQLServer({
    typeDefs: './schema.graphql',
    resolvers,
    context: {
      prisma
    },
  })
  server.start(() => console.log('Server is running on http://localhost:4000')) //Remember to be using localhost:4000 and not 4466