// Express for webserver
const express = require('express');
// Massive for database
const massive = require("massive");
// Bluebird for Promise Library
const promise = require('bluebird');
// Pg Monitor for Monitoring Queries
const monitor = require('pg-monitor');
const bodyParser = require('body-parser');

const DB_USER = "alex";
const DB_HOST = "localhost";
const DB_PORT = 5432;
const DB_NAME = "pgguide";

// ConnectionString: {driver}://{username}:{password?}@{host}:{port}/{db_name}
const connectionString = `postgress://${DB_USER}@${DB_HOST}:${DB_PORT}/${DB_NAME}`;

// Webserver
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
// Parse json data
app.use(bodyParser.json());

// Webserver port
const port = 3000;

massive(connectionString, {}, {
    promiseLib: promise
}).then(db => {
    monitor.attach(db.driverConfig);

    /*
    Q1.1
    List all users email and sex in order of most recently created.
    Do not include password hash in your output 
    */
    app.get('/users', (req, res, next) => {
        db.query(`SELECT    "email",
                            "details"->'sex'    AS sex
                  FROM      "users"
                  ORDER BY  "created_at" DESC`) .then(result => {
            res.json(result);
            res.end();
        });
    });

    /**
     * Q1.2
     * Show above details of the specified user 
     */
    app.get('/users/:id', (req, res, next) => {
        const id = req.params.id;

        db.users.findOne({
            id: id
        }, {
            fields: ['email', 'details']
        }).then(result => {
            res.json(result);
        });
    });

    /**
     * Q1.3 List all products in ascending order of price
     */
    app.get('/products', (req, res, next) => {
        db.products.find({}, {
            order: [
                { field: 'price', direction: 'asc'}
            ]
        }).then(result => {
            res.json(result);
        });
    });

    /**
     * Q1.4
     * Show details of the specified products
     */
    app.get('/products/:id', (req, res, next) => {
        const id = req.params.id;
 
        db.products.findOne({
            id: id
        }).then(result => {
            res.json(result);
        });
    });
    /**
     * Q1.5
     * List purchase items to include the receiver’s name and,
     * address, the purchaser’s email address and the price,
     * quantity and delivery status of the purchased item.
     * Order by price in descending order
     */
    app.get('/purchases', (req, res, next) => {
        db.query(`
        SELECT      purchases.name,
                    purchases.address,
                    purchases.zipcode,
                    purchases.state,
                    users.email,
                    products.title,
                    purchase_items.price,
                    purchase_items.quantity,
                    purchase_items.state AS delivery
 
        FROM        purchase_items
 
        INNER JOIN  purchases
        ON          purchase_items.purchase_id = purchases.id
 
        INNER JOIN  users
        ON          purchases.user_id = users.id
 
        INNER JOIN  products
        ON          purchase_items.product_id = products.id
 
        ORDER BY    purchase_items.price DESC
        `).then(result => {
            res.json(result);
        });
    });
    /**
     * Q2.
     * GET /products[?name=string] 
     * implement the query (badly) in such a way as to allow an attacker to
     *  inject arbitrary SQL code into the query execution. Show, using your badly implemented approach, 
     * how an attacker can craft a query string to allow the deletion of a product from the products table.

     */
    app.get('/unsafequery', (req, res, next) => {
        const name = req.query.name; // ?name=
        //http://127.0.0.1:3000/unsafequery?name=Dictionary
        // http://127.0.0.1:3000/unsafequery?name='; SELECT * FROM users;--
        //UNSAFE QUERY
        db.query("SELECT * FROM products WHERE title LIKE '%" + name + "%' ORDER BY price ASC").then(result => {res.json(result);});
    });
        //Safe Query 1
    app.get('/safequery1', (req, res, next) => {
            const name = req.query.name;
        if (name !== undefined) {
            db.products.find({
                "title ilike": `%${name}%`
            }, {
                order: [
                    { field: 'price', direction: 'asc' }
                ]
            }).then(result => {
                res.json(result);
            });
        } else {
            db.products.find({}, {
                order: [
                    { field: 'price', direction: 'asc'}
                ]
            }).then(result => {
                res.json(result);
            });
        }
    });
        //Safe Query 2- Parametirised query
    app.get('/safequery2', (req, res, next) => {
        const name = req.query.name;
        db.products.where("title ilike $1", [`%${name}%`]).then(products => {
            res.json(products);
        });
    });
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}!`)
});