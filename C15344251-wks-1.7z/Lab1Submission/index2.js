// Express for webserver
const express = require('express');
// Sequelize for database
const Sequelize = require('sequelize');

const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({extended: true }));
app.use(bodyParser.json());
const port = 3000;

const DB_USER = "alex";
const DB_Pid= '';
const DB_HOST = "localhost";
const DB_PORT = 5432;
const DB_NAME = "pgguide";
const DB_DIALECT = "postgres";

const sequelize = new Sequelize(`${DB_DIALECT}://${DB_USER}@${DB_HOST}:${DB_PORT}/${DB_NAME}`);
// Operators
const op = Sequelize.Op;

/**
 * Q4 Create Sequalize migrations for the pgguide sample database
Ensure that the appropriate associations and referential integrity checking are set up in your models

 */
const Users = sequelize.define('users', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id',
        primaryKey: true
    },
    email: { type: Sequelize.STRING, field: 'email' },
    password: { type: Sequelize.STRING, field: 'password' },
    details: { type: Sequelize.HSTORE, field: 'details' },
    created_at: { type: Sequelize.DATE },
    deleted_at: { type: Sequelize.DATE }
}, {
    timestamps: false
});

const Products = sequelize.define('products', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id',
        primaryKey: true
    },
    title: { type: Sequelize.STRING },
    price: { type: Sequelize.NUMERIC },
    tags: { type: Sequelize.ARRAY(Sequelize.STRING)},
    created_at: { type: Sequelize.DATE },
    deleted_at: { type: Sequelize.DATE }
}, {
    timestamps: false
});

const Purchases = sequelize.define('purchases', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id',
        primaryKey: true
    },
    created_at: { type: Sequelize.DATE },
    name: { type: Sequelize.STRING },
    address: { type: Sequelize.STRING },
    state: { type: Sequelize.STRING },
    zipcode: { type: Sequelize.INTEGER },
    user_id: { type: Sequelize.INTEGER},
}, {
    timestamps: false
});

const PurchaseItems = sequelize.define('purchase_items', {
    id: {
        type: Sequelize.INTEGER,
        field: 'id',
        primaryKey: true
    },
    purchase_id: { type: Sequelize.INTEGER },
    product_id: { type: Sequelize.INTEGER },
    price: { type: Sequelize.NUMERIC},
    quantity: { type: Sequelize.INTEGER },
    state: { type: Sequelize.STRING },
}, {
    timestamps: false
});
/**
 * Q6.1 List Product with passed paramteter name
 */
app.get('/products', (req, res, next) => {
    //?=name query
    const name = req.query.name;

    if (name !== undefined) {
        Products.findAll({
            where: {
                title: {
                    [op.iLike]: `%${name}%`
                }
            },
            order: [
                ['price', 'ASC']
            ]
        }).then((products) => {
            res.json(products);
            res.end();
        });
    } else {
        Products.findAll({
            order: [
                ['price', 'ASC']
            ]
        }).then((products) => {
            res.json(products);
        });
    }
});
/**
 * Q6.2 Show details of the specified products
 */
app.get('/products/:id', (req, res, next) => {
    const id = req.params.id;

    if (id !== undefined && !isNaN(id)) {
        Products.findOne({
            where: {
                id: {
                    [op.eq]: id
                }
            }
        }).then((product) => {
            res.json(product);
            res.end();
        });
    } else {
        res.status(404);
        res.end();
    }
});

/**
 *  Q6.3 Create a new product instance
 */
app.put('/products', (req, res, next) => {
    const body = req.body;
    Products.create({
        id: sequelize.literal('DEFAULT'),
        title: body.title,
        price: body.price,
        tags: body.tags,
        created_at: sequelize.literal('CURRENT_TIMESTAMP')
    }).then((product) => {
        res.json(product);
        res.end();
    });
});

/**
 * Q 6.4 Update an existing product
 */
app.post('/products/:id', (req, res, next) => {
    const id= req.params.id;
    const body = req.body;
    Products.update({
        title: body.title,
        price: body.price,
        tags: body.tags
    }, {
        where: {
            id: {
                [op.eq]: id
            }
        }
    }).then((product) => {
        res.json(product);
        res.end();
    });
});
/**
 * Q6.5 Remove an existing product
 */
app.delete('/products/:id', (req, res, next) => {
    const id = req.params.id;

    Products.destroy({
        where: {
            id: {
                [op.eq]: id
            }
        }
    }).then((prod) => {
        res.json(prod);
        res.end();
    });
});

const server = app.listen(port, () => {
    console.log(`Example app listening on port ${port}!`)
});

module.exports = server;