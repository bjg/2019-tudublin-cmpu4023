const request = require('supertest');

describe('Testing sequalise server', () => {
    let app;

    beforeAll(() => {
        app = require('../index2');
    });

    afterAll(() => {
        app.close();
    });
    //Checks order of products if they are ordered by price
    it('Should return products', (done) => {
        request(app).get('/products').then((response) => {
            const body = response.body;
            //request to http server 200 means ok...404 means not found
            expect(response.statusCode).toBe(200);
            expect(body[0].price).toBeLessThanOrEqual(body[1].price);
            done();
        });
    });
    //Return Products
    it('should return product with id 1', (done) => {
        request(app).get('/products/1').then((response) => {
            const body = response.body;
            expect(response.statusCode).toBe(200);
            expect(body.id).toBe(1);
            done();
        });
    });
    //Returns 404 http request
    it('Should return 404', (done) => {
        request(app).get('/products/CallofDuty').then((response) => {
            const body = response.body;
            expect(response.statusCode).toBe(404);
            done();
        });
    });

    it('Should create a new product', (done) => {
        request(app)
        .put('/products')
        .send({ title: 'Testing', price: 97.99, tags: ['Test'] })
        .end((err, res) => {
            const product = res.body;
            expect(product.title).toBe('Testing');
            expect(parseFloat(product.price)).toBe(97.99);
            expect(product.tags).toContain('Test');
            done();
        });
    });

    it('Should update a product', (done) => {
        let product = {title: 'testing', price: 120.45};
        // Create the product
        request(app).put('/products').send(product).end((err, res) => {
            product = res.body;

            // update the product
            request(app).post(`/products/${product.id}`).send({title: 'UpdatedTest'}).end((err, res) => {
                const success = res.body;
                expect(success).toContain(1);
                done();
            });
        });
    });

    it('Should delete a product', (done) => {
        let product = {title: 'testing', price: 120.45};
        // Create the product
        request(app).put('/products').send(product).end((err, res) => {
            product = res.body;

            // Delete the product
            request(app).delete(`/products/${product.id}`).end((err, res) => {
                const success = res.body;
                expect(success).toBe(1);
                done();
            });
        });
    });
});