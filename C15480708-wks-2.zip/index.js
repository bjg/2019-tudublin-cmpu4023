const express = require('express')
const jwt = require('jsonwebtoken')
const massive = require('massive')
const promise = require('bluebird')
const decode = require('jwt-claims')
const monitor = require('pg-monitor')
const bp = require('body-parser')
const app = express()
const crypto = require('crypto')

app.use(bp.json())



//Connect using massive
massive('postgres://postgres:postgres@localhost:5432/worksheet2', {}, {
    promiseLib: promise
}).then(db => {
    monitor.attach(db.driverConfig)

    app.post('/login', (req , res) => {
        const user = {
            uname: req.query.username,
            pword: req.query.password
        }
        
        //Authenticate User 
        //Check the username and password result
        //localhost:5000/login?username=tom&password=test
        db.users.where("name = $1 AND password = crypt($2 , password)", [req.query.username, req.query.password]).then(result => {
            if (result.length > 0 ) {
                jwt.sign({user: user}, 'secretkey', { expiresIn: '1hr' }, (err,token) => {
                    
                    const claims = decode(token)
                    const resJSON = {
                        uname: claims.user.uname,
                        iat: claims.iat,
                        exp: claims.exp,
                        token: token
                    }
                    res.json(resJSON)
                })
            } else {
                res.sendStatus(401)
            }
        })
        
    })

    app.put('/addProduct', verifyToken, (req, res) => {
        //Verify user token then query
        jwt.verify(req.token, 'secretkey', (err, authData) => {
            if(err){
                res.sendStatus(401)
            } else{
                //Add element to table
                db.query("INSERT INTO products (name) VALUES ($1)", [req.query.name]).then(product => {
                    res.json(product)
                })
            }
        })
        
    })

    app.put('/hmacAddProduct', (req, res) => {
        const hmacHash = req.headers.authorization 
        const accessKey = req.body.accessKey
        const info = req.body.message


        const checkHMAC = accessKey+info

        db.query("SELECT secretkey FROM users WHERE accessKey = $1", [accessKey]).then( result => {
            if(result.length > 0){
                
                const secretKey = result[0].secretkey
                const hmac = crypto.createHmac('sha256', secretKey)
                hmac.update(checkHMAC)
                
                const serverHMAC = hmac.digest('hex')

                //Check if hash matches -> if matches, inter
                if(serverHMAC == hmacHash){

                    db.query("INSERT INTO products (name) VALUES ($1)",[info]).then(result => {
                        res.sendStatus(200)
                    })
                    
                }
                else{
                    res.sendStatus(401)
                }
                
            }
            else{
               res.sendStatus(401)
            }
        })

    
    })

})


//Verify the Token
function verifyToken(req,res,next){
    //Get authentication header value
    const bearerHeader = req.headers['authorization']

    //Check if defined
    if(typeof bearerHeader !== 'undefined'){

        const bearer = bearerHeader.split(' ')
        const bearerToken = bearer[1]

        req.token = bearerToken
        next()

    } else{
        res.sendStatus(403)
    }
   


}
app.listen(5000, () => console.log('Server running on port 5000'))