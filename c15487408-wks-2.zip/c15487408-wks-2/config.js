module.exports = {
    port: 3000,
    dbConnectionString: "postgres://postgres:root@localhost/postgres",
    saltRounds: 2,
    jwtSecret: 'its-a-secret',
    tokenExpireTime: '24h'
}