const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto')
const Users = require('../models').User;
const config =  require('../config');

const authenticate = params => {
	//Q4
   var sk = params.secret_key;
   var hmac = crypto.createHmac('sha384', sk).digest('hex');
    return Users.findOne({
        where: {
            login: params.login
        },
        raw: true
   }).then(user => {
        if (!user){
            var response = {status : 404, error : 'Authentication failed. User not found.'};
            return response;
        }
        if (!bcrypt.compareSync(params.password || '', user.password)){
            var response = {status : 40, error : 'Authentication failed. User not found.'};
            return response;
        }
        const payload = {
            login: user.login,
            password: user.password
        };
        // recompute hmac
       var compute_hmac= crypto.createHmac('sha384', user.secret_key).digest('hex');
        if (compute_hmac !== hmac) {
            var response = {status : 403, error : 'Security Check Failed.'};
            return response;
        }
        var token = jwt.sign(payload, config.jwtSecret, {
            expiresIn: config.tokenExpireTime
        });
        var response = {token : token, userid : user.id};
        return response;
    });
}

module.exports = {
    authenticate
}

