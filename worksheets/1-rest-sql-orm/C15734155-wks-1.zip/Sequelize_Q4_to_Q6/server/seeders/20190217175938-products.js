'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('products',
    [
      {title:"Rock CD", price: "1.99", created_at: new Date(), tags:["music","song"]},
      {title:"Scary", price: "2.00", created_at: new Date(), tags:["movie","film"]},
      {title:"Cooking Book", price: "5.99", created_at: new Date(), tags:["cook","reading"]}
    ],{});
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('products',
    {
      title: [
        "Rock CD", 
        "Scary",
        "Cooking Book"
      ]
    });
  }
};