'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
      return queryInterface.bulkInsert('purchases',
    [
      //created_at: ,name: , address:, state: , zipcode: ,user_id:
      {created_at: new Date(),name:"Apple Bottom", address: "122 Abs Street", state:"AB", zipcode:"12471",user_id:"27"},
      {created_at: new Date(),name:"Jeans Boots", address: "345 Moe Ave.", state:"CD", zipcode:"23451", user_id:"5"},
      {created_at: new Date(),name:"De Fur", address: "678 Forest Lane ", state:"EF", zipcode:"34581", user_id:"32"}
    ],{});
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('purchases',
    [
      {name:"Apple Bottom", address: "122 Abs Street", state:"AB", zipcode:"12471", user_id:"27"},
      {name:"Jeans Boots", address: "345 Moe Ave.", state:"CD", zipcode:"23451", user_id:"5"},
      {name:"De Fur", address: "678 Forest Lane ", state:"EF", zipcode:"34581", user_id:"32"}
    ],{});
  }
};