'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
  return queryInterface.bulkInsert('users',
      [
        {
          email:"rusty@yahoo.com",
          password:"good",
          details:'"sex" => "F"',
          created_at: new Date()},
        {
          email:"coco@gmail.com",
          password:"better",
          created_at: new Date()},
        {
          email:"boo@hotmail.com",
          password:"best",details:'"sex" => "M"',
          created_at: new Date()}
      ],{});
    },  

    down: (queryInterface, Sequelize) => {
      return queryInterface.bulkDelete('users',
      {
        email: [
          "hey@gmail.com", 
          "helloey@gmail.com",
          "hello@gmail.com"
        ]
      });
    } 
  };