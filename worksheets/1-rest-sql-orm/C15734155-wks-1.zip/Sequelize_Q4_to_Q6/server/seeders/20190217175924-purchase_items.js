'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('purchase_items', [
      {
        purchase_id: '1',
        product_id: '2',
        price: '125.34',
        quantity: '4',
        state: 'Pending'
      },
      {
        purchase_id: '11',
        product_id: '6',
        price: '8.90',
        quantity: '2',
        state: 'Pending'
      }
    ], {});
},
down: (queryInterface, Sequelize) =>{
    return queryInterface.bulkDelete('purchase_items', {
      purchase_id: ['1', '11'],
      product_id: ['2',  '6'],
      state: ['Pending']
    });
  }
};