'use strict';
module.exports = (sequelize, DataTypes) => {
  const users = sequelize.define('users', {
  email: DataTypes.STRING,
    password: DataTypes.STRING,
    details: DataTypes.HSTORE,
    createdAt: {
      type : Date(),
      field: "created_at"
    },
    deletedAt: {
      type:Date(),
      field: "deleted_at"
    }
  }, {});
  users.associate = function(models) {
    // associations can be defined here
  };
  return users;
};