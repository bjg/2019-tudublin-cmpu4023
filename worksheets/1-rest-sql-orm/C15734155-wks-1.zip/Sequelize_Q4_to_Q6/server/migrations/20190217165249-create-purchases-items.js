'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('purchases_items', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      purchase_id: {type: Sequelize.INTEGER,                    // foreignKey
              references : { model : "purchases", key : "id"},        // ensures referential integrity
              onUpdate: 'cascade',
              onDelete: 'cascade'
            },
            product_id: {type: Sequelize.INTEGER,                     // foreignKey
              references : { model : "products", key : "id"},         // ensures referential integrity
              onUpdate: 'cascade',
              onDelete: 'cascade'
            },
            price: {type: Sequelize.INTEGER},
            quantity: {type: Sequelize.INTEGER},
            state: {type: Sequelize.STRING},
            createdAt: {allowNull: false, type: Sequelize.DATE},
            updatedAt: {allowNull: false, type: Sequelize.DATE}
          });
        },
  down: function(queryInterface, Sequelize) {
    return queryInterface.dropTable('purchase_items');
  }
};