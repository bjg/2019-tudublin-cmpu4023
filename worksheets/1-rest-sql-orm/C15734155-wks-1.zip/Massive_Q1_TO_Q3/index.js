const express = require('express')
const massive = require('massive');

const app = express()
const port = 3000

massive({
    host: 'localhost',
    port: 5432,
    database: 'pgguide',
    user: 'postgres',
    password: '0815',
    ssl: false,
    poolSize: 10,
}).then(instance => {
    app.set('db', instance)

    /* PROBLEM SETS*/

    //PROBLEM SET 1.1
    /**
    List all users email and sex in order of most
    recently created. Do not include password hash in
    your output

    */
    app.get('/users', async (req, res) => {
        const users = await req.app.get('db').query('select email, details -> \'sex\' AS sex from users order by created_at desc;');
        res.json(users);
    });


    //PROBLEM SET 1.2
    //get specific user details using unique id
    app.get('/users/:id', async (req, res) => {
        const users = await req.app.get('db').query('select email, details -> \'sex\' AS sex from users where id = ${id} order by created_at desc;', {
            id: req.params.id,
        });
        res.json(users);
    });


    //PROBLEM SET 1.3
    //List all products in ascending order of price
    //allow the filtering of products by name
    app.get('/products', (req, res) => {
        const search = req.query.name ? { 'title =': req.query.name } : {};
        req.app.get('db').products.find(search).then(products => {
            res.json(products);
        }).catch(err => res.json(err));
    });

    //PROBLEM SET 1.4
    app.get('/products/:id', (req, res) => {
        req.app.get('db').products.find({ 'id =': req.params.id }).then(products => {
            res.json(products);
        });
    });

   //PROBLEM SET 1.5
   //get all purchases
    app.get('/purchases', async (req, res) => {
        const db = await req.app.get('db');
        const result = await db.query(`
        SELECT 
        Products.title,
        purchases.name, 
        purchases.address,
        users.email, 
        purchase_items.price, 
        purchase_items.quantity, 
        Purchase_items.state 
        FROM purchases
        INNER JOIN users on purchases.user_id = users.id 
        INNER JOIN purchase_items on purchase_items.purchase_id = purchases.id
        INNER JOIN products on purchase_items.product_id = products.id
        ORDER BY purchase_items.price DESC;`);
    res.json(result);
    });
    
   //PROBLEM SET 2
   //allows for injection
   app.get('/unsafe/products', async (req, res) => {
        try {
            const byTitle = req.query.name ? `where title = '${req.query.name}'` : ''
            const query = `select * from products ${byTitle};`
            console.log(query)
            const result = await req.app.get('db').query(`select * from products ${byTitle};`);
            res.json(result);
        } catch(err) {
            res.json(err);
        }
    });

   //PROBLEM SET 3
   //sql injection prevention
   //parameterised query
    app.get('/safe/products', async (req, res) => {
        const result = await req.app.get('db').query('select * from products where title = ${name};', {
            name: req.query.name,
        });
        res.json(result);
    });

    //stored procedure
    app.get('/safe2/products', (req, res) => {
   
            //stored procedure
            app.get('db').get_prod(req.query.name).then(product => {
                res.send(product);
            })
    });
    

  
    app.listen(port, () => console.log(`Example app listening on port ${port}!`))
})