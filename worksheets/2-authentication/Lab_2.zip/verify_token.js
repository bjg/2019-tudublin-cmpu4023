let jwt = require('jsonwebtoken');
const config = require('./config.js');

let checkToken = (req, res, next) => {
  let token = req.headers['authorization'];
  if (token.startsWith('Bearer ')) {
    // Remove Bearer from string
    token = token.slice(7, token.length);
  }
  //If token exists
  if (token) {
    //Use the verify token
    jwt.verify(token, config.secret, (err, decoded) => {
      if (err) {
        return res.json({
          success: false,
          message: 'invalid token'
        });
      } else {
        req.decoded = decoded;
        next();//provide access to the protected resource
      }
    });
  } else {
    //token does not exist
    return res.json({
      success: false,
      message: 'authorization token does not exist'
    });
  }
};

module.exports = {
  checkToken: checkToken
}