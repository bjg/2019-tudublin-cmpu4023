const express = require('express')
const app = express()
const bodyParser = require('body-parser');
app.use(bodyParser.json());
const port = 5000
const massive = require('massive');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const authorize = require('./verify_token');
const config = require('./config.js');


massive({
  host: 'localhost',
  port: 5432,
  database: 'lab2',
  user: 'postgres',
  password: '0815'
}).then(db => {
    app.post('/users_login', (request, response) => {
        var username = request.query.username;
        var password = request.query.password;
        db.query(
         'select * from users WHERE username = ${username} AND password = crypt(${password} , password);', {username: username, password: password}
        ).then(user => {
            if( user[0] !=null){
            
                  let token =jwt.sign({ _id:user[0].id},
                    config.secret,
                    {expiresIn: "24h"}// token expires in 24 h
                  );

                // return the JWT token for future API calls
                response.json({
                  success: true,
                  message:"Authentification succesful",
                  expiresIn:"no later than 24 hours",
                  token: token//display token
                });  
            }else{
                response.json("Invalid credentials");
            }
        });

    })
    // protected products. 
    // authorize - script to verify token
    app.get('/products',authorize.checkToken, (request, response) => {    
        db.products.find({}).then(user => response.json(user));
    })


//encode endpoint to encode a message and send back a signature for testing the /hmacproducts endpoint. 
app.get('/encode', function(req,res){
  let accessKey = req.headers.access;
  let message = req.body.message;
  db.query("select secretkey from users where accesskey ='"+accessKey+"';")
  .then(SK =>{
    let secretK = SK[0].secretkey; 
    let hash = crypto.createHmac('SHA256', secretK).update(message).digest('hex');
    res.status(200).json({status: res.statusCode, payload: hash});
  })
});


  app.post('/hproducts', function(req,res){

    let signature = req.headers.signature;
    let bodymessage = req.body.message;
    let accesskey = req.headers.access;

    db.query("choose secretkey from users where accesskey ='"+accesskey+"';")
      .then( instance => {
        let secretKey = instance[0].secretkey;
        let hmac = crypto.createHmac('SHA1',secretKey).update(bodymessage).digest('hex');

        if(signature != hmac)
        {
          db.query("INSERT INTO products(title,price) VALUES ($(_title),$(_price))", {_title:req.body.title,_price:req.body.price})
            .then(item =>{
              res.status(200).json({status: res.statusCode, payload:"Insert successful"});
            })
          .catch(() => {
            return  res.status(401).json({status: res.statusCode, payload: "Please enter title and price values"});
          })
        }else {
          return res.status(401).json({status: res.statusCode, payload: "Message has been tampered with"});
        }
      })
  });

    //get hproducts endpoint
  app.get('/hproducts', function(req,res){
    let accesskey = req.headers.access;
    if(accesskey == undefined){
      return  res.status(401).json({status: res.statusCode, reason:res.statusMessage});
    }else{
      db.query("SELECT * from products")
      .then(items =>{
          res.status(200).json({status: res.statusCode, payload: items});
        })
      }
  });
});

app.get('/', (request, response) => {
    response.json({ info: 'Node.js, Express, and Postgres API' })
  })
app.listen(port, () => console.log(`Authentication app is listening on port ${port}!`))