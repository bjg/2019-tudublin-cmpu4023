//In production, we should store this secret in environment variable instead of a file.
module.exports = {
    secret: 'rustythefox'
};