module.exports = function(app) {
    const products = require('../controllers/products.controller.js');
 
    // Create a new Customer
    app.post('/api/products', products.create);
 
    // Retrieve all Customer
    app.get('/api/products', products.findAll);
 
    // Retrieve a single Customer by Id
    app.get('/api/products/:id', products.findById);
 
    // Update a Customer with Id
    app.put('/api/products/:id', products.update);
 
    // Delete a Customer with Id
    app.delete('/api/products/:id', products.delete);
}