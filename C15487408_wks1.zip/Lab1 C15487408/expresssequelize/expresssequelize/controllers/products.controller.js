const db = require('../config/db.config.js');
const Product = db.products;
 
// Post a Customer
exports.create = (req, res) => {	
	// Save to PostgreSQL database
	Product.create(req.body).then(product => {		
			// Send created customer to client
			res.status(200).json(product);
		}).catch(err => {
			console.log(err);
			res.status(500).json({msg: "error", details: err});
		});
};
 
// 2. FETCH All Customers
exports.findAll = (req, res) => {
	var name = req.query.name;
	if (name === undefined){
	Product.findAll().then(product => {
			// Send All Customers to Client
			res.status(200).json(product);
			return product;
		}).catch(err => {
			console.log(err);
			res.status(500).json({msg: "error", details: err});
		});	
	} else {
		Product.findAll(
				{
		  where: {
			title: name			
		  }
		}
		).then(product => {
			// Send All Customers to Client
			res.status(200).json(product);
		}).catch(err => {
			console.log(err);
			res.status(500).json({msg: "error", details: err});
		});
	}
	
};
 
// 3. Find a Customer by Id
exports.findById = (req, res) => {	
	Product.findById(req.params.id).then(product => {
			res.status(200).json(product);
		}).catch(err => {
			console.log(err);
			res.status(500).json({msg: "error", details: err});
		});
};
 
// 4. Update a Product
exports.update = (req, res) => {
	const id = req.params.id;
	Product.update( req.body, 
			{ where: {id: id} }).then(() => {
				res.status(200).json( { msg: "Updated Successfully -> Customer Id = " + id } );
			}).catch(err => {
				console.log(err);
				res.status(500).json({msg: "error", details: err});
			});
};
 
// Delete a Product by Id
exports.delete = (req, res) => {
	const id = req.params.id;
	Product.destroy({
			where: { id: id }
		}).then(() => {
			res.status(200).json( { msg: 'Deleted Successfully -> Customer Id = ' + id } );
		}).catch(err => {
			console.log(err);
			res.status(500).json({msg: "error", details: err});
		});
};