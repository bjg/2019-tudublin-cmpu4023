
module.exports = (sequelize, Sequelize) => {
	const Products = sequelize.define('products', {
	  
	  title: {
			type: Sequelize.STRING
	  },
	  price: {
			type: Sequelize.NUMERIC
	  },
	  created_at: {
			type: Sequelize.DATE
	  },
	  deleted_at: {
			type: Sequelize.DATE
	  },
	  tags: {
			type: Sequelize.ARRAY(Sequelize.STRING)
	  }
	}, {
    timestamps: false
});
	
	return Products;
}