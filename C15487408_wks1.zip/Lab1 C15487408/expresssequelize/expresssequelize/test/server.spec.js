var request = require("request");
var base_url;
var expect = require('chai').expect;
 
describe("describe REST API : ", function() {
    base_url = "http://localhost:3000/products";
    it("Returns status code 200 for get all products", function(done) {
        request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        done();
        });
    });

    it("Returns status code 200 and return one product for get by id", function(done) {
        base_url = "http://localhost:3000/api/products/2";
        request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        expect(JSON.parse(response.body).id).equal(2);
        done();
        });
    });

    it("Returns status code 200 and return one product for get by filter name", function(done) {
        base_url = "http://localhost:3000/api/products?name=Dictionary";
        request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        expect(JSON.parse(response.body)[0].title).equal('Dictionary');
        done();
        });
    });

    it("Returns status code 200 and return one product for create a product", function(done) {
        base_url = "http://localhost:3000/api/products";
        request.post({
            headers: {'content-type' : 'application/json'},
            url : base_url, 
            body : {"title":"R Book","price":"49.99","created_at":"2011-01-01T20:00:00.000Z","deleted_at":null,"tags":["Book","Programming","R"]},
            json: true
            },
            function(error, response, body) {
                expect(response.statusCode).equal(200);
                expect(response.body.title).equal('R Book');
                done();
        });
    });

    it("Returns status code 200 and return message", function(done) {
        base_url = "http://localhost:3000/api/products/2";
        request.put({
            headers: {'content-type' : 'application/json'},
            url : base_url, 
            body : {"title":"Academic Book"},
            json: true
            },
            function(error, response, body) {
                expect(response.statusCode).equal(200);
                expect(response.body.msg).equal('Updated Successfully -> Customer Id = 2');
                done();
        });
    });

    it("Returns status code 200 and return message", function(done) {
        base_url = "http://localhost:3000/api/products/24";
        request.delete({
            headers: {'content-type' : 'application/json'},
            url : base_url, 
            body : {"title":"Academic Book"},
            json: true
            },
            function(error, response, body) {
                expect(response.statusCode).equal(200);
                expect(response.body.msg).equal('Deleted Successfully -> Customer Id = 24');
                done();
        });
    });
});
