const express = require('express');
const router = express.Router();
const app = express();
const pg = require('pg');
const path = require('path');
var connectionString = "postgres://postgres:root@localhost/pgguide";
const port = 3000;

const config = {
    port: 5432,
  database: 'pgguide',
  user: 'postgres',
  password: 'root'
};
  
const pool = new pg.Pool(config);
  
app.get('/users/:id', (req, res, next) => {
  const results = [];
  const id = req.params.id;
  // Get a Postgres client from the connection pool
  pool.connect((err, client, done) => {
    // Handle connection errors
    if(err) {
      done();
      console.log(err);
      return res.status(500).json({success: false, data: err});
    }
    // SQL Query > Select Data
    const query = client.query('SELECT * FROM users WHERE id = ($1)', [id]);
    // Stream results back one row at a time
    query.on('row', (row) => {
      results.push(row);
    });
    // After all data is returned, close connection and return results
    query.on('end', () => {
      done();
      return res.json(results);
    });
  });
});  

app.listen(port, () => console.log(`Example app listening on port ${port}!`));


app.get('/usersbyprocedure/:id', function (req, res, next) {
	const results = [];
  const id = req.params.id;
    pg.connect(connectionString,function(err,client,done) {
       if(err){
           console.log("not able to get connection "+ err);
           res.status(400).send(err);
       } 
       // SQL Query > Select Data
    const query = client.query('SELECT * FROM GetAllUSers() WHERE id = ($1)', [id]);
    // Stream results back one row at a time
    query.on('row', (row) => {
      results.push(row);
    });
    // After all data is returned, close connection and return results
    query.on('end', () => {
      done();
      return res.json(results);
    });
    });
});

