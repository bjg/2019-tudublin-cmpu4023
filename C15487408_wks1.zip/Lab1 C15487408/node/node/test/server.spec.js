var request = require("request");
var base_url;
var expect = require('chai').expect;
 
describe("describe REST API : ", function() {
    it("Returns status code 200 for get all products", function(done) {
        base_url = "http://localhost:3000/products";
		request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        done();
        });
    });

    it("Returns status code 200 and return one product for get by id=2", function(done) {
        base_url = "http://localhost:3000/products/2";
        request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
		console.log('++ ' + response.body);
        expect(JSON.parse(response.body)[0].id).equal(2);
        done();
        });
    });

    it("Returns status code 200 and return one product for get by filter name", function(done) {
        base_url = "http://localhost:3000/products?name=Dictionary";
        request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        expect(JSON.parse(response.body)[0].title).equal('Dictionary');
        done();
        });
    });

	 it("Returns status code 200 for get all users", function(done) {
        base_url = "http://localhost:3000/users";
		request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        done();
        });
    });

    it("Returns status code 200 and return one user for get by id=2", function(done) {
        base_url = "http://localhost:3000/users/2";
        request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        done();
        });
    });
	
	it("Returns status code 200 for get all purchases", function(done) {
        base_url = "http://localhost:3000/purchases";
		request.get(base_url, function(error, response, body) {
        expect(response.statusCode).equal(200);
        done();
        });
    });
});
