
const express = require('express');
const app = express();
const monitor = require('pg-monitor');
const massive = require('massive');
const port = 3000;

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
var connectionString = "postgres://postgres:root@localhost/pgguide";
var instance;

massive({
  host: 'localhost',
  port: 5432,
  database: 'pgguide',
  user: 'postgres',
  password: 'root'
	}).then(db => {
	  monitor.attach(db.driverConfig);
	  instance = db;
});

// 1
  app.get('/users', (req, res) =>   
  instance.query('select email,details from users order by created_at desc').then(data => { 
   res.status(200).send(data);
  }));

  app.get('/users/:id', (req, res) =>   
  instance.query('select email,details from users where id= '+req.params.id).then(data => { 
   res.send(data);
  })
  );
 
  app.get('/products', (req, res) =>  { 
  if (req.query.name === undefined){
	  instance.query('select * from products order by price').then(data => { 
       res.status(200).send(data);
  })
  } else {
	  instance.query("select * from products where title = '" + req.query.name + "'").then(data => { 
   res.status(200).send(data);
  })  
  }
  
  });
  
  app.get('/products/:id', (req, res) =>   
  instance.query('select * from products where id= '+req.params.id).then(data => { 
   res.status(200).send(data);
  })
  );

  app.get('/purchases', (req, res) =>   
  instance.query('select * from purchases').then(data => { 
   res.status(200).send(data);
  })
  );

  //http://localhost:3000/users/2%20OR%201=1
  
